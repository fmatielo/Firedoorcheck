// android/app/build.gradle
android {
    compileSdkVersion 33

    defaultConfig {
        applicationId "com.example.firedoor_check"
        minSdkVersion 21
        targetSdkVersion 33
        // ...
    }
    // ...
}